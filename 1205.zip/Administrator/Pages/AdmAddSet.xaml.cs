﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdmAddSet.xaml
    /// </summary>
    public partial class AdmAddSet : Page
    {
        private DBEntities Connection;
        decimal price = 0;
        public List<Dish> Dishes { get; set; }
        public HashSet<Dish> Sets { get; set; }
        public List<Dish> DishesOfSet { get; set; }
        public HashSet<DishSet> CompoundSet { get; set; }
        public DishSet SelectedSetCompound { get; set; }

        public AdmAddSet()
        {
            InitializeComponent();
            Sets = new HashSet<Dish>();
            CompoundSet = new HashSet<DishSet>();
            Connection = Lib.Connector.GetModel();
            Dishes = Connection.Dish.ToList();
            
            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(Administrator.Resources.GetPagesList());
        }

        private void DishListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var dish = DishListBox.SelectedItem as Dish;
            Sets.Add(DishListBox.SelectedItem as Dish);
            DishesOfSet = Sets.ToList();
            CompoundSet.Add(new DishSet() {Dish1 = dish});
            ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty).UpdateTarget();
        }
        private void UpdateQuantityBinding()
        {
            foreach(var dish in CompoundSet)
            {
                price +=Math.Round((dish.Dish1.Cost*Convert.ToInt32(DishCount)*Convert.ToDecimal(1.15)),2);
            }
            SetCost.Text = Convert.ToString(price);
            DishCount.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
            ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
            DishCount.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
        }
        private void SelectionChange(object sender, SelectionChangedEventArgs e)
        {
            if (ListDishes.SelectedIndex > -1)
            {
                DishCount.IsEnabled = true;

                var dish = ListDishes.SelectedItem as Dish;
                if (dish != null)
                {
                    var list = CompoundSet.Where(x => x.Dish1.Name==dish.Name).ToList();

                    if (list.Count > 0)
                    {
                        SelectedSetCompound = list[0];
                    }
                    else
                    {
                        SelectedSetCompound = null;
                    }
                    UpdateQuantityBinding();
                }
            }
            else
            {
                DishCount.IsEnabled = false;
            }
        }

        private void ListDishes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListDishes.SelectedIndex > -1)
            {
                Sets.Remove(ListDishes.SelectedItem as Dish);
                DishesOfSet = Sets.ToList();
                ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
            }
        }
    }
}
