﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator
{
    /// <summary>
    /// Логика взаимодействия для Authorisation.xaml
    /// </summary>
    public partial class Authorisation : Page
    {


        int count = 0;
        private Timestamp Block; 

        public Authorisation()
        {
            InitializeComponent();
            CaptchaCreate();
            
        }

        private void CaptchaCreate()
        {
            Captcha.Text = "";
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#@&$?!";
            Random r = new Random();
            for (int i = 0; i < 6; i++)
            {
                Captcha.Text += letters.Substring(r.Next(0, letters.Length - 1),1);
            }
            
        }

        private void RetryButton_Click(object sender, RoutedEventArgs e)
        {
            CaptchaCreate();
        }

        private bool CheckBlocking() 
        {
            Block = Lib.Connector.GetModel().Timestamp.OrderBy(b => b.Time).FirstOrDefault();
            if (Block == null) return false;
            return Block.Time>DateTime.Now;
        }

        private void LogIn_Click(object sender, RoutedEventArgs e)
        {
            var DB = Lib.Connector.GetModel();
            var list = DB.Employees.ToList();
            if(count>=3)
            { 
                DB.Timestamp.Add(new Timestamp() { Time=DateTime.Now.AddMinutes(1) });
                DB.SaveChanges();
                MessageBox.Show("ревышено количество попыток, вход заблокирован на 1 минуту.");
                count = 0;
                
            }
            if(CheckBlocking()==true)
            {
                
                int time = (int)(Block.Time - DateTime.Now).TotalSeconds;
                MessageBox.Show("Вход заблокирован ещё " + time + " секунд");
                return;
            }

            foreach (var employee in list)
            {
                if (Login.Text == employee.Login && Password.Text == employee.Password)
                {
                    if (Captcha.Text==Text.Text)
                    {
                       MessageBox.Show("Вы успешно вошли");
                       NavigationService.Navigate(Administrator.Resources.GetPagesList());
                       return;
                    }
                    else
                    {
                        MessageBox.Show("Текст не совпадает!");
                        CaptchaCreate();
                        Text.Text = "";
                        count++;
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль");
                    count++;
                    return;
                }
            }
        }
    }
}
