﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administrator.Lib
{
    internal class Connector
    {
        private static Employees profile;
		private static DBEntities AppDbConnector;

		public static DBEntities GetModel()
		{
			if (AppDbConnector == null)
			{
				AppDbConnector = new DBEntities();
			}

			return AppDbConnector;
		}

		public static Employees GetMyProfile()
		{
			return profile;
		}

		public static bool Authorize(string login, string password)
		{
			string login1 = login.Trim();
			string pwd = password.Trim();
			profile = GetModel().Employees.Where(emp => emp.Login == login1 && emp.Password == pwd).FirstOrDefault();
			return profile != null;
		}
    }
}
