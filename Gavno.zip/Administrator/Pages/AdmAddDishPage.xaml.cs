﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdmAddDishPage.xaml
    /// </summary>
    public partial class AdmAddDishPage : Page
    {
        private DBEntities Connection;
        public Unit Unit { get; set; }

        private List<Ingredient> Ingredients { get; set; }
        public List<Ingredient> IngredientsOfDish { get; set; }
        public HashSet<Ingredient> IngredientSet { get; set; }
        private List<Unit> Units { get; set; }

        public HashSet<DishCompound> DishCompoundSet { get; set; }
        public DishCompound SelectedDishCompound { get; set; }

        public AdmAddDishPage()
        {
            InitializeComponent();
            IngredientSet = new HashSet<Ingredient>();
            DishCompoundSet = new HashSet<DishCompound>();
            Connection = Lib.Connector.GetModel();
            if (UnitCB.ItemsSource == null)
            {
                Units = Connection.Unit.ToList();
                UnitCB.ItemsSource = Units;
            }
            if (IngListBox.ItemsSource == null)
            {
                Ingredients = Connection.Ingredient.ToList();
                IngListBox.ItemsSource = Ingredients;
            }
            DataContext = this;
           

        }

        private void UpdateQuantityBinding()
        {
            UnitCB.GetBindingExpression(ComboBox.SelectedItemProperty)?.UpdateTarget();
            IngQuantity.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
            ListIngredients.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
        }


        private void Update()
        {
            Connection.SaveChanges();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(Administrator.Resources.GetPagesList());
        }

        private void IngListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var ingredient = IngListBox.SelectedItem as Ingredient;
            IngredientSet.Add(IngListBox.SelectedItem as Ingredient);
            IngredientsOfDish = IngredientSet.ToList();
            DishCompoundSet.Add(new DishCompound() { Ingredient = ingredient });

            ListIngredients.GetBindingExpression(ListBox.ItemsSourceProperty).UpdateTarget();
        }

        private void SelectionChange(object sender, SelectionChangedEventArgs e)
        {
            if (ListIngredients.SelectedIndex > -1)
            {
                IngQuantity.IsEnabled = true;
                UnitCB.IsEnabled = true;

                var ingredient = ListIngredients.SelectedItem as Ingredient;
                if (ingredient != null)
                {
                    var list = DishCompoundSet.Where(x => x.Ingredient.Name == ingredient.Name).ToList();

                    if (list.Count > 0)
                    {
                        SelectedDishCompound = list[0];
                    }
                    else
                    {
                        SelectedDishCompound = null;
                    }
                    UpdateQuantityBinding();
                }
            }
            else
            {
                IngQuantity.IsEnabled = false;
                UnitCB.IsEnabled = false;
            }
        }

        private void ListIngredients_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListIngredients.SelectedIndex > -1)
            {
                IngredientSet.Remove(ListIngredients.SelectedItem as Ingredient);
                IngredientsOfDish = IngredientSet.ToList();
                ListIngredients.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var name = DishName.Text.Trim();
            if(name=="")
            {
                MessageBox.Show("Имя для блюда не было введено");
                return;
            }
            var search = Connection.Dish.ToList();
            foreach(var item in search)
            { if (item.Name == name)
                {
                    MessageBox.Show("Блюдо с таким именем уже сесть");
                    return; }
            }
            decimal cost = 0;
            if (decimal.TryParse(DishCost.Text.Trim(), out cost) == true || DishCost.Text!="0")
            {
                Dish dish = new Dish()
                {
                    Name = name,
                    Cost = cost,
                };

                Connection.Dish.Add(dish);

                foreach (var item in DishCompoundSet)
                {
                    item.DishName = name;
                    if (item.Quantity == 0)
                    {
                        MessageBox.Show("Введите количество игредиента");
                        Connection.Dish.Remove(dish);
                        return;
                    }
                    if (item.Unit1 == null)
                    {
                        MessageBox.Show("Выберите единицу измерения ингредиента");
                        Connection.Dish.Remove(dish);
                        return;
                    }

                    Connection.DishCompound.Add(item);
                }

                Connection.SaveChanges();

              
                IngredientsOfDish = new List<Ingredient>();
                SelectedDishCompound = null;

                UpdateQuantityBinding();

                DishName.Text="";
                DishCost.Text = "";
                SelectedDishCompound = null;
                MessageBox.Show("Блюдо успешно добавлено!");
            }
            else { MessageBox.Show("Цена не была введена"); return; }
        }
    }
}
