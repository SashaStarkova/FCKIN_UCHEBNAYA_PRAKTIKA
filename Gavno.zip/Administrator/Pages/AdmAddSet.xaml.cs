﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    public class DISH
    {
        public Dish dish { get; set; }
        public int count { get; set; }

    }
    /// <summary>
    /// Логика взаимодействия для AdmAddSet.xaml
    /// </summary>
    public partial class AdmAddSet : Page
    {
        private DBEntities Connection;
        public decimal price { get; set; } = 0;
        public List<Dish> Dishes { get; set; }
        public HashSet<Dish> Sets { get; set; }
        public List<Dish> DishesOfSet { get; set; }
        public Dictionary<string, DISH> CompoundSet { get; set; }
        public DISH SelectedDishCount { get; set; }

        public AdmAddSet()
        {
            InitializeComponent();
            Sets = new HashSet<Dish>();
            CompoundSet = new Dictionary<string, DISH>();
            Connection = Lib.Connector.GetModel();
            Dishes = Connection.Dish.ToList();

            DataContext = this;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(Administrator.Resources.GetPagesList());
        }

        private void DishListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var dish = DishListBox.SelectedItem as Dish;
            Sets.Add(DishListBox.SelectedItem as Dish);
            DishesOfSet = Sets.ToList();

            if (CompoundSet.ContainsKey(dish.Name))
            {
                CompoundSet[dish.Name].count++;
            }
            else
            {
                CompoundSet.Add(dish.Name, new DISH() { count = 1, dish = dish });
            }

            PriceCalc();

            ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
        }
        private void UpdateQuantityBinding()
        {
            DishCount.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
            ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();
            SetCost.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
        }
        private void SelectionChange(object sender, SelectionChangedEventArgs e)
        {
            if (ListDishes.SelectedIndex > -1)
            {
                DishCount.IsEnabled = true;

                var dish = ListDishes.SelectedItem as Dish;
                if (dish != null)
                {
                    if (CompoundSet.ContainsKey(dish.Name))
                    {
                        SelectedDishCount = CompoundSet[dish.Name];
                        UpdateQuantityBinding();
                    }
                }

                PriceCalc();
            }
            else
            {
                DishCount.IsEnabled = false;
            }
        }

        private void PriceCalc()
        {
            price = 0;

            foreach (var d in CompoundSet)
            {
                price += Math.Round(d.Value.dish.Cost * d.Value.count * Convert.ToDecimal(1.15), 2);
            }

            SetCost.GetBindingExpression(TextBox.TextProperty)?.UpdateTarget();
        }

        private void ListDishes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListDishes.SelectedIndex > -1)
            {
                var dish = ListDishes.SelectedItem as Dish;

                Sets.Remove(dish);
                DishesOfSet = Sets.ToList();

                if (CompoundSet.ContainsKey(dish.Name))
                {
                    CompoundSet.Remove(dish.Name);
                }

                ListDishes.GetBindingExpression(ListBox.ItemsSourceProperty)?.UpdateTarget();

                PriceCalc();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (SetName.Text == "")
            {
                MessageBox.Show("Вы не ввели имя сета!");
                return;
            }
            foreach (var sets in Connection.Set)
            {
                if (SetName.Text == sets.Name)
                {
                    MessageBox.Show("Сет с таким именем уже существует!");
                    return;
                }
            }
            if (CompoundSet == null)
            {
                MessageBox.Show("Сет пуст!");
                return;
            }

            Set set = new Set();
            set.Name = SetName.Text;
            Connection.Set.Add(set);
            foreach (var item in CompoundSet)
            {
                DishSet ds = new DishSet();
                ds.Name = SetName.Text;
                ds.Dish = item.Value.dish.Name;
                ds.Count = item.Value.count;
                Connection.DishSet.Add(ds);
            }
            Connection.SaveChanges();
            MessageBox.Show("Сет успешно добавлен!");
            SetName.Text = "";
            CompoundSet.Clear();
            DishesOfSet = new List<Dish>();
            SelectedDishCount = null;
            price = 0;
            UpdateQuantityBinding();

        }
    }
}
