﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdmMainPage.xaml
    /// </summary>
    public partial class AdmMainPage : Page
    {
        public Employees SelectedEmployee { get; set; }

        private List<Employees> Employees { get; set; }

        private List<Roles> Roles { get; set; }

        private void RolesBox()
        {
            var roleList = Lib.Connector.GetModel().Roles.ToList();
            Role.Items.Clear();
            foreach (var item in roleList)
            {
                Role.Items.Add(item);
            }
        }
        public void Activate()
        {
            Employees = Lib.Connector.GetModel().Employees.ToList();

            EmpListBox.ItemsSource = Employees;
        }

        public AdmMainPage()
        {
            InitializeComponent();
            RolesBox();
            Activate();
        }

        // я все сломал

        public void UpdateUser(object sender, RoutedEventArgs e)
        {
            
        }
        public void RegisterUser(object sender, RoutedEventArgs e)
        {
            var employee = new Employees();
            employee.Name = UserName.Text.Trim();
            employee.Login = Login.Text.Trim();
            employee.Password = Password.Text.Trim();
            employee.Roles = Role.SelectedItem as Roles;
            Lib.Connector.GetModel().Employees.Add(employee);
            Lib.Connector.GetModel().SaveChanges();
        }

     


        private void Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void EmpListBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (EmpListBox.SelectedIndex != -1)
            {
                Register.Click -= RegisterUser;
                Register.Click += UpdateUser;
                Register.Content = "Обновить";

                SelectedEmployee = EmpListBox.SelectedItem as Employees;
                UserName.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
                Login.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
                Password.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            }
            else
            {
                Register.Click -= UpdateUser;
                Register.Click += RegisterUser;
                Register.Content = "Регистрация";
            }
        }

        private void EmpListBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
