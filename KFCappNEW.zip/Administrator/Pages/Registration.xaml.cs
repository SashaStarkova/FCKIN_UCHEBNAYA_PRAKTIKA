﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        private void RolesBox()
        {
            var roleList = Lib.Connector.GetModel().Roles.ToList();
            Role.Items.Clear();
            foreach (var item in roleList)
            {
                Role.Items.Add(item);
            }
        }
        public Registration()
        {
            InitializeComponent();
            RolesBox();
            UserName = null;
            Login = null;
            Password = null;
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            var DB = Lib.Connector.GetModel();
            Employees newemp = new Employees();
            Roles role = Role.SelectedItem as Roles;
            if (UserName != null && Login != null && Password != null && role != null)
            {
                newemp.Name = UserName.Text;
                newemp.Login = Login.Text;
                newemp.Password = Password.Text;
                newemp.RoleNumber = role.RoleNumber;
                DB.Employees.Add(newemp);
                DB.SaveChanges();
                NavigationService.Navigate(Administrator.Resources.GetAuthorization());
            }
            else { MessageBox.Show("Заполните все поля!"); }

        }
    }
}
