﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdmAddDishPage.xaml
    /// </summary>
    public partial class AdmAddDishPage : Page
    {
        private DBEntities Connection;
        public Ingredient Ingredient { get; set; }
        public Unit Unit { get; set; }

        private List<Ingredient> Ingredients { get; set; }
        private List<Unit> Units { get; set; }

        public AdmAddDishPage()
        {
            InitializeComponent();
            Connection = Lib.Connector.GetModel();
            if (UnitCB.ItemsSource == null)
            {
                Units = Connection.Unit.ToList();
                UnitCB.ItemsSource = Units;
            }
            if (IngListBox.ItemsSource == null)
            {
                Ingredients = Connection.Ingredient.ToList();
                IngListBox.ItemsSource = Ingredients;
            }
            DataContext = this;
            UpdateIngredientList();


        }
        private void UpdateIngredientList()
        {
           
        }

        private void Update()
        {
            Connection.SaveChanges();
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(Administrator.Resources.GetPagesList());
        }

        private void IngListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListIngredients.Items.Add(IngListBox.SelectedItem);
        }

        private void SelectionChange(object sender, SelectionChangedEventArgs e)
        {
            ListIngredients.Items.Remove(ListIngredients.SelectedItem);
        }
    }
}
