﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFCappNEW.Pages
{
    /// <summary>
    /// Логика взаимодействия для PurchasePage.xaml
    /// </summary>
    public partial class PurchasePage : Page
    {
        public PurchasePage()
        {
            InitializeComponent();
            Build();
        }

        public struct BuscketInfo
        {
            public bool IsSet;
            public int Count;
        }
       
        public static Dictionary<string, BuscketInfo> Buscket = new Dictionary<string, BuscketInfo>();

        public void Build()
        {
            Database.DBEntities Connection = new Database.DBEntities();
            Stack.Children.Clear();

            foreach (var val in Buscket)
            {
                StackPanel BusckList = new StackPanel();
                BusckList.VerticalAlignment = VerticalAlignment.Center;
                BusckList.Height = 200;
                BusckList.Width = 800;
                BusckList.Orientation=Orientation.Horizontal;
                BusckList.Background=new SolidColorBrush(Colors.PeachPuff);
                BusckList.Margin=new Thickness(0,0,0,20);
                Stack.Children.Add(BusckList);

                StackPanel NameAndNum = new StackPanel();
                NameAndNum.Orientation = Orientation.Vertical;
                NameAndNum.HorizontalAlignment = HorizontalAlignment.Center;
                NameAndNum.Margin = new Thickness(35, 20, 0, 10);
                BusckList.Children.Add(NameAndNum);

                TextBlock Name = new TextBlock();
                if (val.Value.IsSet)
                { Name.Text = "Сет " +val.Key; }
                else { Name.Text = val.Key; }
                Name.Width = 500;
                Name.Height = 50;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Franklin Gothic Demi");
                Name.FontSize = 22;
                NameAndNum.Children.Add(Name);

                StackPanel CountStack = new StackPanel();
                CountStack.Orientation = Orientation.Horizontal;
                NameAndNum.Children.Add(CountStack);

                Label Count = new Label();
                Count.Content = "Количество";
                Count.Width = 150;
                Count.Height = 60;
                Count.FontSize = 22;
                Count.FontFamily = new FontFamily("Franklin Gothic Demi");
                Count.Margin = new Thickness(0, 20, -10, 0);
                CountStack.Children.Add(Count);

                Button CountDown = new Button();
                CountDown.Content = "➖";
                CountDown.FontFamily = new FontFamily("Franklin Gothic Demi");
                CountDown.FontSize = 26;
                CountDown.Width = 50;
                CountDown.Height = 50;
                CountStack.Children.Add(CountDown);

                TextBlock CountNum = new TextBlock();
                CountNum.Width = 50;
                CountNum.Height = 50;
                CountNum.FontFamily = new FontFamily("Franklin Gothic Demi");
                CountNum.FontSize = 22;
                CountNum.Margin= new Thickness(25,20,-10,0);
                CountNum.Text = val.Value.Count.ToString();
                CountStack.Children.Add(CountNum);

                Button CountUp = new Button();
                CountUp.Content = "+";
                CountUp.FontFamily = new FontFamily("Franklin Gothic Demi");
                CountUp.FontSize = 40;
                CountUp.Width = 50;
                CountUp.Height = 50;
                CountStack.Children.Add(CountUp);

                StackPanel PriceAndDel = new StackPanel();
                PriceAndDel.Orientation = Orientation.Vertical;
                PriceAndDel.HorizontalAlignment = HorizontalAlignment.Center;
                PriceAndDel.Margin = new Thickness(0, 20, 0, 10);
                BusckList.Children.Add(PriceAndDel);

                TextBlock Price = new TextBlock();
                Price.Width = 100;
                Price.Height = 50;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Franklin Gothic Demi");
                Price.FontSize = 22;
                List<Database.Dish> dishList = new List<Database.Dish>();
                decimal price = 0;
                if (val.Value.IsSet == false)
                {
                    
                    foreach (var dish in dishList)
                    {
                        if (dish.Name == val.Key)
                        { Price.Text = (dish.Cost).ToString(); break; }

                    }
                }
                else { List<Database.DishSet> setList = new List<Database.DishSet>();

                foreach(var set in setList)
                    {
                        if(set.Name == val.Key) 
                        { 
                        foreach(var dish in dishList)
                            { if (set.Dish == dish.Name)
                                { price += dish.Cost; }
                            }
                        }
                    }
                    price = price * Convert.ToDecimal(1.1);
                    Price.Text = Convert.ToString(price);
                }

                
                PriceAndDel.Children.Add(Price);

                Button del = new Button();
                del.Width = 200;
                del.Height = 50;
                del.FontFamily= new FontFamily("Franklin Gothic Demi");
                del.FontSize = 22;
                del.Margin = new Thickness(0, 16, 0, 0);
                del.Content = "Удалить блюдо";
                PriceAndDel.Children.Add(del);

            }
            //{
            //    StackPanel SetPanel = new StackPanel();
            //    SetPanel.Orientation = Orientation.Horizontal;
            //    SetPanel.VerticalAlignment = VerticalAlignment.Center;
            //    SetPanel.Height = 200;
            //    SetPanel.Width = 800;
            //    SetPanel.Margin = new Thickness(0, 0, 0, 20);
            //    SetPanel.Background = new SolidColorBrush(Colors.PeachPuff);
            //    MenuList.Children.Add(SetPanel);

            //    StackPanel NameAndCompound = new StackPanel();
            //    NameAndCompound.Orientation = Orientation.Vertical;
            //    NameAndCompound.HorizontalAlignment = HorizontalAlignment.Center;
            //    NameAndCompound.Margin = new Thickness(35, 20, 0, 10);
            //    SetPanel.Children.Add(NameAndCompound);

            //    TextBlock Name = new TextBlock();
            //    Name.Text = "Сет " + set.Name;
            //    Name.Width = 500;
            //    Name.Height = 50;
            //    Name.TextWrapping = TextWrapping.Wrap;
            //    Name.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    Name.FontSize = 22;
            //    NameAndCompound.Children.Add(Name);

            //    TextBlock Compound = new TextBlock();

            //    decimal price = 0;
            //    Compound.Text = "♥ Состав сета ♥\n";
            //    List<Database.DishSet> dishList = set.DishSet.ToList();
            //    foreach (var dish in dishList)
            //    {
            //        Compound.Text += Convert.ToString(dish.Dish1.Name);
            //        if (dish.Count > 1)
            //        {
            //            Compound.Text += " " + dish.Count + " шт.";

            //        }
            //        Compound.Text += "\n";
            //        price += dish.Dish1.Cost;
            //    }
            //    price = price * Convert.ToDecimal(1.1);
            //    Compound.Width = 500;
            //    Compound.Height = 100;
            //    Compound.TextWrapping = TextWrapping.Wrap;
            //    Compound.FontFamily = new FontFamily("Franklin Gothic");
            //    Compound.FontSize = 18;
            //    NameAndCompound.Children.Add(Compound);

            //    StackPanel PriceAndButton = new StackPanel();
            //    PriceAndButton.Orientation = Orientation.Vertical;
            //    PriceAndButton.HorizontalAlignment = HorizontalAlignment.Center;
            //    PriceAndButton.Margin = new Thickness(0, 10, 0, 10);
            //    SetPanel.Children.Add(PriceAndButton);

            //    TextBlock Price = new TextBlock();
            //    Price.Text = "(っ◔◡◔)っ " + Math.Round(price, 2) + " руб.";
            //    Price.Width = 300;
            //    Price.Height = 90;
            //    Price.TextWrapping = TextWrapping.Wrap;
            //    Price.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    Price.FontSize = 22;
            //    Price.Margin = new Thickness(0, 10, 0, 0);
            //    PriceAndButton.Children.Add(Price);

            //    Button AddDish = new Button();
            //    AddDish.Width = 220;
            //    AddDish.Height = 60;
            //    AddDish.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    AddDish.FontSize = 22;
            //    AddDish.Content = "Добавить в корзину";
            //    AddDish.HorizontalAlignment = HorizontalAlignment.Left;
            //    PriceAndButton.Children.Add(AddDish);
            //}
            //foreach (var dish in menuList)
            //{
            //    StackPanel dishPanel = new StackPanel();
            //    dishPanel.Orientation = Orientation.Horizontal;
            //    dishPanel.VerticalAlignment = VerticalAlignment.Center;
            //    dishPanel.Height = 200;
            //    dishPanel.Width = 800;
            //    dishPanel.Margin = new Thickness(0, 0, 0, 20);
            //    dishPanel.Background = new SolidColorBrush(Colors.PapayaWhip);
            //    MenuList.Children.Add(dishPanel);

            //    StackPanel NameAndCalories = new StackPanel();
            //    NameAndCalories.Orientation = Orientation.Vertical;
            //    NameAndCalories.HorizontalAlignment = HorizontalAlignment.Center;
            //    NameAndCalories.Margin = new Thickness(35, 20, 0, 10);
            //    dishPanel.Children.Add(NameAndCalories);

            //    TextBlock Name = new TextBlock();
            //    Name.Text = dish.Name;
            //    Name.Width = 500;
            //    Name.Height = 120;
            //    Name.TextWrapping = TextWrapping.Wrap;
            //    Name.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    Name.FontSize = 22;
            //    NameAndCalories.Children.Add(Name);

            //    TextBlock Calories = new TextBlock();
            //    List<Database.DishCompound> ingredient = Connection.DishCompound.ToList();
            //    double calories = 0;
            //    foreach (var ing in ingredient)
            //    {
            //        if (ing.Unit == "шт." && ing.DishName == dish.Name)
            //        {
            //            calories += ing.Quantity * ing.Ingredient.Calories;
            //        }
            //        else if (ing.DishName == dish.Name)
            //        {
            //            calories += ing.Quantity * ing.Ingredient.Calories / 100;
            //        }

            //    }
            //    Calories.Text = Convert.ToString(calories) + " ккал.";
            //    Calories.Width = 500;
            //    Calories.Height = 100;
            //    Calories.TextWrapping = TextWrapping.Wrap;
            //    Calories.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    Calories.FontSize = 22;
            //    NameAndCalories.Children.Add(Calories);

            //    StackPanel PriceAndButton = new StackPanel();
            //    NameAndCalories.Orientation = Orientation.Vertical;
            //    NameAndCalories.HorizontalAlignment = HorizontalAlignment.Center;
            //    dishPanel.Children.Add(PriceAndButton);

            //    TextBlock Price = new TextBlock();
            //    Price.Text = "(っ◔◡◔)っ " + Convert.ToString(Math.Round(dish.Cost, 2)) + " руб.";
            //    Price.Width = 300;
            //    Price.Height = 90;
            //    Price.TextWrapping = TextWrapping.Wrap;
            //    Price.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    Price.FontSize = 22;
            //    Price.Margin = new Thickness(0, 20, 0, 10);
            //    PriceAndButton.Children.Add(Price);

            //    Button AddDish = new Button();
            //    AddDish.Width = 220;
            //    AddDish.Height = 60;
            //    AddDish.FontFamily = new FontFamily("Franklin Gothic Demi");
            //    AddDish.FontSize = 22;
            //    AddDish.Content = "Добавить в корзину";
            //    AddDish.HorizontalAlignment = HorizontalAlignment.Left;
            //    PriceAndButton.Children.Add(AddDish);

            //}


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(MainWindow.Menu);
        }
    }
}
