﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFCappNEW.Pages
{
    /// <summary>
    /// Логика взаимодействия для MenuPage.xaml
    /// </summary>
    public partial class MenuPage : Page
    {
        public MenuPage()
        {
            InitializeComponent();
            Build();
        }
        void Build()
        {
            Database.DBEntities Connection = new Database.DBEntities();

            List<Database.Dish> menuList = Connection.Dish.OrderBy(m => m.Name).ToList();
            MenuList.Children.Clear();
            List<Database.Set> setList = Connection.Set.OrderBy(m => m.Name).ToList();
            foreach (var set in setList)
            {
                StackPanel SetPanel = new StackPanel();
                SetPanel.Orientation = Orientation.Horizontal;
                SetPanel.VerticalAlignment = VerticalAlignment.Center;
                SetPanel.Height = 200;
                SetPanel.Width = 860;
                SetPanel.Margin = new Thickness(0, 0, 0, 20);
                SetPanel.Background = new SolidColorBrush(Colors.PeachPuff);
                MenuList.Children.Add(SetPanel);

                StackPanel NameAndCompound = new StackPanel();
                NameAndCompound.Orientation = Orientation.Vertical;
                NameAndCompound.HorizontalAlignment = HorizontalAlignment.Center;
                SetPanel.Children.Add(NameAndCompound);

                TextBlock Name = new TextBlock();
                Name.Text = set.Name;
                Name.Width = 500;
                Name.Height = 60;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Franklin Gothic Demi");
                Name.FontSize = 22;
                NameAndCompound.Children.Add(Name);

                TextBlock Compound = new TextBlock();

                decimal price = 0;
                Compound.Text = "(っ◔◡◔)っ ♥ Состав сета ♥ \n";
                List<Database.DishSet> dishList = set.DishSet.ToList();
                foreach (var dish in dishList)
                {
                    Compound.Text += Convert.ToString(dish.Dish1.Name)+"\n";
                    price += dish.Dish1.Cost;
                }
                price = price * Convert.ToDecimal(1.1);
                Compound.Width = 500;
                Compound.Height = 100;
                Compound.TextWrapping = TextWrapping.Wrap;
                Compound.FontFamily = new FontFamily("Franklin Gothic");
                Compound.FontSize = 18;
                NameAndCompound.Children.Add(Compound);

                StackPanel PriceAndButton = new StackPanel();
                PriceAndButton.Orientation = Orientation.Vertical;
                PriceAndButton.HorizontalAlignment = HorizontalAlignment.Center;
                SetPanel.Children.Add(PriceAndButton);

                TextBlock Price = new TextBlock();
                Price.Text = "(っ◔◡◔)っ " + Math.Round(price, 2) + " руб.";
                Price.Width = 300;
                Price.Height = 100;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Franklin Gothic Demi");
                Price.FontSize = 22;
                PriceAndButton.Children.Add(Price);

                Button AddDish = new Button();
                AddDish.Width = 220;
                AddDish.Height = 60;
                AddDish.FontFamily = new FontFamily("Franklin Gothic Demi");
                AddDish.FontSize = 22;
                AddDish.Content = "Добавить в корзину";
                AddDish.HorizontalAlignment = HorizontalAlignment.Left;
                PriceAndButton.Children.Add(AddDish);
            }
            foreach (var dish in menuList)
            {
                StackPanel dishPanel = new StackPanel();
                dishPanel.Orientation = Orientation.Horizontal;
                dishPanel.VerticalAlignment = VerticalAlignment.Center;
                dishPanel.Height = 200;
                dishPanel.Width = 860;
                dishPanel.Margin = new Thickness(0, 0, 0,20);
                dishPanel.Background = new SolidColorBrush(Colors.PapayaWhip);
                MenuList.Children.Add(dishPanel);

                StackPanel NameAndCalories = new StackPanel();
                NameAndCalories.Orientation = Orientation.Vertical;
                NameAndCalories.HorizontalAlignment = HorizontalAlignment.Center;
                dishPanel.Children.Add(NameAndCalories);

                TextBlock Name = new TextBlock();
                Name.Text = dish.Name;
                Name.Width = 500;
                Name.Height = 100;
                Name.TextWrapping = TextWrapping.Wrap;
                Name.FontFamily = new FontFamily("Franklin Gothic Demi");
                Name.FontSize = 22;
                NameAndCalories.Children.Add(Name);

                TextBlock Calories = new TextBlock();
                List<Database.DishCompound> ingredient = Connection.DishCompound.ToList();
                double calories = 0;
                foreach (var ing in ingredient)
                {
                    if (ing.Unit == "шт." && ing.DishName == dish.Name)
                    {
                        calories += ing.Quantity * ing.Ingredient.Calories;
                    }
                    else if (ing.DishName == dish.Name)
                    {
                        calories += ing.Quantity * ing.Ingredient.Calories / 100;
                    }

                }
                Calories.Text = Convert.ToString(calories) + " ккал.";
                Calories.Width = 500;
                Calories.Height = 100;
                Calories.TextWrapping = TextWrapping.Wrap;
                Calories.FontFamily = new FontFamily("Franklin Gothic Demi");
                Calories.FontSize = 22;
                NameAndCalories.Children.Add(Calories);

                StackPanel PriceAndButton = new StackPanel();
                NameAndCalories.Orientation = Orientation.Vertical;
                NameAndCalories.HorizontalAlignment = HorizontalAlignment.Center;
                dishPanel.Children.Add(PriceAndButton);

                TextBlock Price = new TextBlock();
                Price.Text = "(っ◔◡◔)っ " + Convert.ToString(Math.Round(dish.Cost, 2)) + " руб.";
                Price.Width = 300;
                Price.Height = 100;
                Price.TextWrapping = TextWrapping.Wrap;
                Price.FontFamily = new FontFamily("Franklin Gothic Demi");
                Price.FontSize = 22;
                PriceAndButton.Children.Add(Price);

                Button AddDish = new Button();
                AddDish.Width = 220;
                AddDish.Height = 60;
                AddDish.FontFamily = new FontFamily("Franklin Gothic Demi");
                AddDish.FontSize = 22;
                AddDish.Content = "Добавить в корзину";
                AddDish.HorizontalAlignment = HorizontalAlignment.Left;
                PriceAndButton.Children.Add(AddDish);

            }


        }


    }
}
