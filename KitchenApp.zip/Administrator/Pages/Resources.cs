﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administrator
{
    
		public static class Resources
		{
			private static Authorisation authorization;
			private static Registration registrationSuperUser;
		    private static Pages.AdmMainPage admmainpage;

			public static Authorisation GetAuthorization()
			{
				if (authorization == null)
				{
					authorization = new Authorisation();
				}

				return authorization;
			}

			public static Registration GetRegistrationSuperUser()
			{
				if (registrationSuperUser == null)
				{
					registrationSuperUser = new Registration();
				}

				return registrationSuperUser;
			}
		public static Pages.AdmMainPage GetMainPage() {
			if (admmainpage == null)
			{
				admmainpage = new Pages.AdmMainPage();
			}

			return admmainpage;
		}
		}
}
