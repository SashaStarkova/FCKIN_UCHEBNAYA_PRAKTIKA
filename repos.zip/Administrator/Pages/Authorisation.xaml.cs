﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator
{
    /// <summary>
    /// Логика взаимодействия для Authorisation.xaml
    /// </summary>
    public partial class Authorisation : Page
    {
        public Authorisation()
        {
            InitializeComponent();
        }

        private void LogIn_Click(object sender, RoutedEventArgs e)
        {
            var DB = Lib.Connector.GetModel();
            var list = DB.Employees.ToList();
            foreach (var employee in list)
            {
                if (Login.Text == employee.Login && Password.Text == employee.Password)
                {
                    CaptchaWin captcha = new CaptchaWin();
                    if (captcha.ShowDialog() == true)
                    {
                       MessageBox.Show("Вы успешно вошли");
                       NavigationService.Navigate(Administrator.Resources.GetPagesList());
                       return;
                    }
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль");
                    return;
                }
            }
        }
    }
}
