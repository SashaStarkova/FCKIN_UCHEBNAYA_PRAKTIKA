﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Administrator.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdmMainPage.xaml
    /// </summary>
    public partial class AdmMainPage : Page
    {
        private DBEntities Connection;

        public Employees SelectedEmployee { get; set; }

        public List<Employees> Employees { get; set; }

        public List<Roles> Roles { get; set; }


        public AdmMainPage()
        {
            InitializeComponent();
            Connection = Lib.Connector.GetModel();
            Roles = Connection.Roles.ToList();
            DataContext = this;
            UpdateEmployeeList();
        }

        private void Activate(object sender, MouseButtonEventArgs e)
        {
            UpdateEmployeeList();
        }
        private void UpdateEmployeeList()
        {
            Employees = Connection.Employees.Where(Employees=>Employees.Status=="Раб.").ToList();
        }

        private void Update()
        {
            Connection.SaveChanges();
        }

        public void UpdateUser(object sender, RoutedEventArgs e)
        {
            
            Update();
            EmpListBox.SelectedIndex = -1;
            MessageBox.Show("Данные сотрудника успешно обновлены");
            ClearTextBox();

        }
        public void Registration()
        {
            var employee = new Employees();
            employee.Name = UserName.Text.Trim();
            employee.Login = Login.Text.Trim();
            employee.Password = Password.Text.Trim();
            employee.Roles = Role.SelectedItem as Roles;
            employee.Status = "Раб.";
            Connection.Employees.Add(employee);
        }

        private void RegisterUser(object sender, RoutedEventArgs e)
        {
            
            Registration();
            Update();
            UpdateEmployeeList();
            ClearTextBox();

            MessageBox.Show("Сотрудник успешно зарегистрирован");
        }

        private void UpdateBinding()
        {
            UserName.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            Login.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            Password.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
            Role.GetBindingExpression(ComboBox.SelectedItemProperty).UpdateTarget();

        }
        private void ClearTextBox()
        {
            UserName.Text = "";
            Login.Text = "";
            Password.Text = "";
            Role.SelectedIndex = -1;
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            foreach (var employee in Connection.Employees)
            {
                if (employee.Login == Login.Text)
                {
                    employee.Status = "Свободен";
                }
            }
            Update();
            UpdateEmployeeList();
            ClearTextBox();

        }

        private void EmpListBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (EmpListBox.SelectedIndex != -1)
            {
                if(Login.IsEnabled != false) { Login.IsEnabled = false; }
                
               UpdateB.IsEnabled = true;
               UpdateB.Visibility = Visibility.Visible;
               Register.IsEnabled = false;
               Register.Visibility = Visibility.Hidden;

                SelectedEmployee = EmpListBox.SelectedItem as Employees;

                UpdateBinding();
            }
            else
            {
                if (Login.IsEnabled == false) { Login.IsEnabled = true; }
                UpdateB.IsEnabled = false;
                UpdateB.Visibility = Visibility.Hidden;
                Register.IsEnabled = true;
                Register.Visibility = Visibility.Visible;

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(Administrator.Resources.GetPagesList());
        }


    }
}
