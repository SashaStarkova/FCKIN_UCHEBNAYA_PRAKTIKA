﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Administrator
{
    
		public static class Resources
		{
			private static Authorisation authorization;
			private static Registration registrationSuperUser;
		    private static Pages.AdmMainPage admmainpage;
		    private static Pages.PagesList pageslist;
		    private static Pages.AdmAddDishPage admadddishpage;
		private static Pages.AdmAddSet admaddsetpage;
		    
			
		public static Authorisation GetAuthorization()
			{
				if (authorization == null)
				{
					authorization = new Authorisation();
				}

				return authorization;
			}

			public static Registration GetRegistrationSuperUser()
			{
				if (registrationSuperUser == null)
				{
					registrationSuperUser = new Registration();
				}

				return registrationSuperUser;
			}
		public static Pages.AdmMainPage GetMainPage() {
			if (admmainpage == null)
			{
				admmainpage = new Pages.AdmMainPage();
			}

			return admmainpage;
		}
		public static Pages.PagesList GetPagesList()
		{
			if (pageslist == null)
			{
				pageslist = new Pages.PagesList();
			}

			return pageslist;
		}

		public static Pages.AdmAddDishPage GetAdmAddDishPage()
		{
			if (admadddishpage == null)
			{
				admadddishpage = new Pages.AdmAddDishPage();
			}

			return admadddishpage;
		}
		public static Pages.AdmAddSet GetAdmAddSet()
		{
			if (admaddsetpage == null)
			{
				admaddsetpage = new Pages.AdmAddSet();
			}

			return admaddsetpage;
		}
	}
}
